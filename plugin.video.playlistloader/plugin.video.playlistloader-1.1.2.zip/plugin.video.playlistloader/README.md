plugin.video.playlistloader

- Forked from @Nux007 and translated to Python 3 for Kodi 19.x

- EPG Support added by @Silhouette2022 (for more information read changelog.txt)